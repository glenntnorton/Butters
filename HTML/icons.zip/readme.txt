"34aL volume 3.2 SE" icons set

Ammount of icons:
60

Colors: 
1. Colored with shadow
2. Colored without shadow 
3. Grey
4. 30% transparent

Icon Sizes:
24x24

File Types:
.ico (RGBA, 256 color, 16 color), 
.tiff (RGBA)
.gif (indexed)
.bmp (RGB - 1 color background), 
.png (RGBA)

Note: These icons are free for use.